# ZalithBoost 1.3.0 — optimizaciones internas

Cambios implementados:
- FrameStats mantiene el muestreo por frame, pero recalcula promedio/mínimo/máximo cada 10 frames, no tres barridos completos de la ventana de 120 muestras en cada render.
- Targeting ejecuta el raycast de bloque/entidad cada 4 ticks (aprox. 5 veces por segundo), mientras actualiza distancia y suavizado del objetivo entre escaneos.
- AlertsHud reemplaza el bucle de draw calls laterales por dos bandas laterales, reduciendo llamadas de dibujo cuando está activa la alerta de vida baja.
- HudManager sale inmediatamente cuando no hay elementos del HUD habilitados.
- Los overlays propios de ZalithBoost no se dibujan al abrir inventario, cofres, pausa u otra pantalla. El render vanilla de Minecraft permanece intacto.
- Autoajuste usa umbrales sostenidos y cambios lentos para evitar oscilación de distancias.
- No se fuerza GC durante la partida.

Límites:
- No se parcheó el renderer vanilla de la hotbar/inventario ni el pipeline de chunks: son rutas críticas y pueden chocar con Sodium, Iris, VulkanMod y renderers adaptados de Android. Se mantiene la implementación vanilla para no introducir incompatibilidades.
- La reducción de raycasts y overlays puede reducir trabajo propio del mod, pero no garantiza un aumento fijo de FPS.
- El cliente no puede acelerar la generación/envío de chunks del servidor.
- Pendiente: compilar y probar en Minecraft 1.21.1, especialmente en Zalith Launcher y junto a los renderers/mods instalados.
