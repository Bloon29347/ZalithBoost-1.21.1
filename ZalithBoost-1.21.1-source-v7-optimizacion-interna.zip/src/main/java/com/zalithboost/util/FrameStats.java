package com.zalithboost.util;

/** Registro ligero de frametimes. Los agregados se recalculan cada 10 frames. */
public final class FrameStats {
    private static final float[] R = new float[120];
    private static int idx, cnt, frames;
    private static long last;
    private static int avgFps, minFps, maxFps;

    private FrameStats() {}

    public static void frame() {
        long n = System.nanoTime();
        if (last != 0) {
            float ms = (n - last) / 1_000_000f;
            if (ms > 0.05f && ms < 1000f) {
                R[idx] = ms;
                idx = (idx + 1) % R.length;
                if (cnt < R.length) cnt++;
            }
        }
        last = n;
        if (++frames >= 10) {
            frames = 0;
            recalc();
        }
    }

    private static void recalc() {
        if (cnt == 0) { avgFps = minFps = maxFps = 0; return; }
        double sum = 0;
        float slowest = 0, fastest = Float.MAX_VALUE;
        for (int i = 0; i < cnt; i++) {
            float v = back(i);
            sum += v;
            if (v > slowest) slowest = v;
            if (v > 0.05f && v < fastest) fastest = v;
        }
        avgFps = (int)Math.round(1000.0 / (sum / cnt));
        minFps = slowest <= 0 ? 0 : Math.round(1000f / slowest);
        maxFps = fastest == Float.MAX_VALUE ? 0 : Math.round(1000f / fastest);
    }

    public static int count() { return cnt; }
    public static float back(int k) { return R[Math.floorMod(idx - 1 - k, R.length)]; }
    public static int avg() { return avgFps; }
    public static int min() { return minFps; }
    public static int max() { return maxFps; }
}
