package com.zalithboost.perf;

import com.zalithboost.config.ZbConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.client.option.ParticlesMode;
import net.minecraft.text.Text;

/** Control adaptativo de presión gráfica; evita cambios frecuentes y no toca hilos internos. */
public final class Perf {
    private static int tickC, low, high, gcC;
    private static int baseRender = -1, baseSimulation = -1, lastRender = -1, lastSimulation = -1;
    private static ParticlesMode baseParticles;
    private static boolean throttled;
    private static int savedFps;

    private Perf() {}

    public static void tick(MinecraftClient mc) {
        if (mc.world == null || mc.player == null) return;
        if (++tickC % 20 == 0) { auto(mc); thermal(mc); }
        gc(mc);
    }

    private static void auto(MinecraftClient mc) {
        ZbConfig z = ZbConfig.I;
        if (!z.autoAdjust || mc.currentScreen != null || throttled) return;
        GameOptions o = mc.options;
        int render = o.getViewDistance().getValue();
        int sim = o.getSimulationDistance().getValue();
        if (baseRender < 0) { baseRender = render; baseSimulation = sim; }
        else {
            if (lastRender >= 0 && render != lastRender) baseRender = render;
            if (lastSimulation >= 0 && sim != lastSimulation) baseSimulation = sim;
        }

        int fps = mc.getCurrentFps();
        int target = Math.max(20, z.targetFps);
        if (fps > 0 && fps < target * 0.82) { low++; high = 0; }
        else if (fps >= target * 1.20) { high++; low = 0; }
        else { low = Math.max(0, low - 1); high = Math.max(0, high - 1); }

        int minView = Math.max(2, Math.min(z.minRender, baseRender));
        if (low >= 5) {
            if (render > minView) o.getViewDistance().setValue(--render);
            else if (sim > 5) o.getSimulationDistance().setValue(--sim);
            else if (baseParticles == null) {
                baseParticles = o.getParticles().getValue();
                o.getParticles().setValue(ParticlesMode.MINIMAL);
            }
            low = 0;
        } else if (high >= 12) {
            if (baseParticles != null) { o.getParticles().setValue(baseParticles); baseParticles = null; }
            else if (sim < baseSimulation) o.getSimulationDistance().setValue(++sim);
            else if (render < baseRender) o.getViewDistance().setValue(++render);
            high = 0;
        }
        lastRender = o.getViewDistance().getValue();
        lastSimulation = o.getSimulationDistance().getValue();
    }

    private static void thermal(MinecraftClient mc) {
        ZbConfig z = ZbConfig.I;
        if (!z.thermalMode) { if (throttled) restoreThrottle(); return; }
        float t = com.zalithboost.util.SystemMonitor.tempC;
        if (Float.isNaN(t)) return;
        if (!throttled && t >= z.thermalLimit) {
            savedFps = mc.options.getMaxFps().getValue();
            mc.options.getMaxFps().setValue(30);
            throttled = true;
            msg(mc, "zalithboost.msg.thermal_on");
        } else if (throttled && t < z.thermalLimit - 3) restoreThrottle();
    }

    public static void restoreThrottle() {
        if (!throttled) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        mc.options.getMaxFps().setValue(savedFps);
        throttled = false;
        msg(mc, "zalithboost.msg.thermal_off");
    }

    // GC opcional solo en menú de pausa; no forzar recolección durante exploración.
    private static void gc(MinecraftClient mc) {
        int mins = ZbConfig.I.gcMinutes;
        if (mins > 0 && ++gcC >= mins * 1200 && mc.currentScreen instanceof GameMenuScreen) {
            System.gc();
            gcC = 0;
        }
    }

    public static void applyProfile(int p) {
        switch (p) {
            case 0 -> apply(4, 5, 120, ParticlesMode.MINIMAL, CloudRenderMode.OFF, GraphicsMode.FAST, false, 0.5, 0, false);
            case 1 -> apply(8, 6, 90, ParticlesMode.DECREASED, CloudRenderMode.FAST, GraphicsMode.FAST, false, 0.75, 0, false);
            case 2 -> apply(12, 8, 60, ParticlesMode.ALL, CloudRenderMode.FANCY, GraphicsMode.FANCY, true, 1.25, 2, true);
            default -> apply(3, 5, 60, ParticlesMode.MINIMAL, CloudRenderMode.OFF, GraphicsMode.FAST, false, 0.5, 0, false);
        }
    }

    private static void apply(int view, int sim, int fps, ParticlesMode pm, CloudRenderMode cm, GraphicsMode gm,
                              boolean shadows, double entScale, int blend, boolean bob) {
        MinecraftClient mc = MinecraftClient.getInstance();
        GameOptions o = mc.options;
        o.getViewDistance().setValue(view);
        o.getSimulationDistance().setValue(sim);
        o.getMaxFps().setValue(fps);
        o.getParticles().setValue(pm);
        o.getCloudRenderMode().setValue(cm);
        o.getGraphicsMode().setValue(gm);
        o.getEntityShadows().setValue(shadows);
        o.getEntityDistanceScaling().setValue(entScale);
        o.getBiomeBlendRadius().setValue(blend);
        o.getBobView().setValue(bob);
        baseRender = baseSimulation = lastRender = lastSimulation = -1;
        low = high = 0;
        baseParticles = null;
        o.write();
        o.sendClientSettings();
        msg(mc, "zalithboost.msg.profile_applied");
    }

    public static void applyReduceMotion(boolean on) {
        GameOptions o = MinecraftClient.getInstance().options;
        o.getBobView().setValue(!on);
        o.getFovEffectScale().setValue(on ? 0.0 : 1.0);
        o.getDistortionEffectScale().setValue(on ? 0.0 : 1.0);
    }

    private static void msg(MinecraftClient mc, String key) {
        if (mc.player != null) mc.player.sendMessage(Text.translatable(key), true);
    }
}
