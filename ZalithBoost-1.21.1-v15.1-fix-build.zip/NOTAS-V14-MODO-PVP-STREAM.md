# ZalithBoost v14 — Modo PvP / directo

Minecraft 1.21.1 · Fabric · Java 21

## Cambios
- Nueva opción `Ocultar HUD y mano (estilo F1) sin pulsar F1` en Rendimiento.
- Cancela el renderizado del HUD vanilla durante el juego cuando la opción está activa: hotbar, corazones, hambre, armadura, experiencia, mira y demás elementos del HUD.
- Cancela el renderizado de la mano y el objeto en primera persona.
- Omite el HUD personalizado, botón flotante y actualizaciones de Targeting/Alerts mientras el modo está activo.
- La opción está desactivada por defecto y se guarda en `config/zalithboost.json`.
- El inventario como pantalla sigue funcionando y se dibuja normalmente cuando se abre; no se ocultan sus slots ni botones para no romper su uso.

## Límites y advertencias
- Ocultar el HUD reduce trabajo de dibujo, pero el coste de hotbar/HUD normalmente es pequeño comparado con chunks, entidades, partículas y renderizado del mundo. No se garantiza un gran aumento de FPS ni 120 FPS constantes.
- No se modifica el motor interno de Sodium, el inventario de Minecraft ni los mods de terceros.
- El renderizado de la mano se cancela mediante un mixin de `GameRenderer.renderHand`; debe verificarse con la compilación de GitHub Actions para el mapeo exacto de Yarn 1.21.1.
- Probar primero en un mundo de prueba. Si el juego falla al iniciar, desactivar/retirar v14 y compartir el log de latest.log.
