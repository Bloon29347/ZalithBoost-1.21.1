# ZalithBoost v15 — HUD visible y PvP

Minecraft 1.21.1 · Fabric · Java 21

## Objetivo
Mantener visible la hotbar vanilla, corazones, hambre, armadura, experiencia,
mira, mano y objeto en primera persona. No se simula F1 ni se cancela el renderizado
del HUD o de la mano.

## Cambios
- Se elimina la opción v14 que ocultaba todo el HUD y la mano.
- Se retiran los mixins de InGameHud y GameRenderer que cancelaban esos dibujos.
- Se conserva el HUD vanilla y el inventario normal.
- El HUD personalizado de coordenadas conserva su dibujo cada frame, pero actualiza
  bioma, traducciones y cadenas cada 5 ticks para evitar trabajo repetido.
- Se conserva la búsqueda de objetivo con la frecuencia limitada que ya tenía v14.

## Límites
- La hotbar vanilla y los iconos siguen dibujándose normalmente para mantener animaciones,
  selección de ranura, durabilidad, conteos y estados correctos.
- No se promete una gran subida de FPS por optimizar la interfaz: el coste mayor suele
  estar en el mundo, chunks, entidades, partículas y renderizador.
- No se modifica el motor interno de Sodium ni de otros mods.
- ZIP verificado; compilación Gradle y prueba en dispositivo pendientes.
