# ZalithBoost v13 — perfil conservador de bloques y chunks

Base: fuente v12. Objetivo: POCO X6 5G, Minecraft 1.21.1, Fabric y Java 21.

## Cambios reales en esta versión
- Añade un perfil manual «Optimizar bloques y chunks» en Rendimiento.
- El perfil limita la distancia de render a un máximo de 8 chunks y la simulación a un máximo de 5, pone la mezcla de biomas en 0, desactiva nubes y sombras de entidades, y reduce la distancia de entidades a un máximo de 0.75.
- No cambia el modo gráfico, partículas, texturas, mipmaps ni efectos de mods; intenta conservar la apariencia principal.
- Evita el raycast periódico del HUD de enemigo cuando su tarjeta está desactivada.

## Límites importantes
- Esto optimiza la carga de escena mediante opciones vanilla y reduce trabajo propio de ZalithBoost. No modifica el motor de renderizado de bloques de Sodium, el compilador de chunks ni el sistema de iluminación de otros mods.
- El perfil es manual y reversible cambiando las opciones desde el menú de rendimiento o las opciones de Minecraft. Anota tus valores anteriores si quieres restaurarlos exactamente.
- No se garantizan FPS concretos. El resultado depende de la escena, shaders, paquetes de recursos, versión de Sodium y temperatura del dispositivo.

## Validación
- ZIP verificado estructuralmente.
- Compilación Gradle pendiente: este entorno no tiene Gradle instalado. Ejecutar GitHub Actions con Java 21 y revisar el resultado antes de instalar el JAR.
- Probar en el mismo mundo, ruta y ajustes gráficos, comparando frametime y FPS antes/después.
