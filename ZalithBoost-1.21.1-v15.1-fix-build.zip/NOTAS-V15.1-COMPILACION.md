# ZalithBoost v15.1 — Corrección de compilación

Se corrige `FloatButton.java`: se elimina la referencia obsoleta a
`ZbConfig.competitiveHudHidden`, campo que fue retirado al conservar visible el HUD.
El botón flotante ahora depende únicamente de `floatButton`.

No se vuelve a ocultar la hotbar, HUD, mira, mano ni objeto en primera persona.
Minecraft 1.21.1 · Fabric · Java 21.

ZIP validado. La compilación Gradle debe confirmarse en GitHub Actions.
