# ZalithBoost v12 — perfil de diagnóstico para POCO X6 5G

Base: código fuente v11 entregado por el usuario. Minecraft 1.21.1, Fabric y Java 21.

## Cambios incluidos
- Muestreo de frametime desacoplado del elemento FPS del HUD: continúa registrando mientras se dibuja el HUD del juego aunque el elemento FPS esté desactivado.
- Estadísticas recientes de FPS promedio, 1% low aproximado, percentil 95 de frametime y peor frametime de la ventana.
- Medición ligera de duración de ticks del cliente y recuento de ticks que superan 50 ms.
- Nueva sección de diagnóstico para comparar caídas de frames y ticks lentos.
- Recomendación JVM para dispositivos con 8.5–16 GB de RAM física ajustada a -Xmx3072M y -Xms1024M, dejando memoria al sistema Android y a la GPU.
- No cambia automáticamente distancia de render, partículas, gráficos, Sodium ni C2ME.

## Límites
Estas métricas ayudan a distinguir problemas de fluidez del cliente, pero no instrumentan directamente el planificador de chunks de Sodium ni miden el tiempo de generación de terreno del servidor. El mod sigue siendo exclusivamente cliente. No se promete una cantidad fija de FPS.

## Compilación y pruebas pendientes
El proyecto requiere compilarse con Java 21 y Gradle 8.12 mediante GitHub Actions. Esta sesión no dispone de Gradle instalado, por lo que la compilación y la ejecución en el POCO X6 5G siguen pendientes.

## Recomendación de prueba
Comparar la misma ruta de exploración en un mundo individual y en un servidor, con idéntica distancia de render y límite de FPS. Guardar capturas del apartado Diagnóstico antes y durante la caída.
