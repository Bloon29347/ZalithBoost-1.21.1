package com.zalithboost.util;

/** Mide el tiempo del tick del cliente sin intervenir en la lógica del juego. */
public final class TickStats {
    private static final float[] SAMPLES = new float[120];
    private static int index, count, slowTicks;
    private static long startedAt;
    private static float averageMs, maxMs;

    private TickStats() {}

    public static void start() { startedAt = System.nanoTime(); }

    public static void end() {
        if (startedAt == 0L) return;
        float ms = (System.nanoTime() - startedAt) / 1_000_000.0f;
        startedAt = 0L;
        if (ms < 0.1f || ms > 2000.0f) return;
        float old = count == SAMPLES.length ? SAMPLES[index] : 0f;
        if (count == SAMPLES.length && old > 50f) slowTicks--;
        SAMPLES[index] = ms;
        if (ms > 50f) slowTicks++;
        index = (index + 1) % SAMPLES.length;
        if (count < SAMPLES.length) count++;
        float total = 0f, max = 0f;
        for (int i = 0; i < count; i++) { total += SAMPLES[i]; if (SAMPLES[i] > max) max = SAMPLES[i]; }
        averageMs = total / count;
        maxMs = max;
    }

    public static int count() { return count; }
    public static int slowTicks() { return slowTicks; }
    public static float averageMs() { return averageMs; }
    public static float maxMs() { return maxMs; }
}
