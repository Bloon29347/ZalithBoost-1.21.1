package com.zalithboost.util;

import java.util.Arrays;

/** Muestreo ligero de frametime. Se alimenta desde el callback de HUD, no desde un elemento opcional. */
public final class FrameStats {
    private static final float[] SAMPLES = new float[120];
    private static int index, count, frames;
    private static long lastNanos;
    private static int average, minimum, maximum, lowOnePercent;
    private static float p95Millis, worstMillis;

    private FrameStats() {}

    public static void frame() {
        long now = System.nanoTime();
        if (lastNanos != 0L) {
            float ms = (now - lastNanos) / 1_000_000.0f;
            if (ms >= 0.1f && ms <= 1000.0f) {
                SAMPLES[index] = ms;
                index = (index + 1) % SAMPLES.length;
                if (count < SAMPLES.length) count++;
            }
        }
        lastNanos = now;
        if (++frames >= 10) { frames = 0; calculate(); }
    }

    private static void calculate() {
        if (count == 0) { average = minimum = maximum = lowOnePercent = 0; p95Millis = worstMillis = 0; return; }
        double total = 0;
        float fastest = Float.MAX_VALUE, slowest = 0;
        float[] sorted = new float[count];
        for (int i = 0; i < count; i++) {
            float sample = SAMPLES[Math.floorMod(index - 1 - i, SAMPLES.length)];
            sorted[i] = sample; total += sample;
            if (sample > slowest) slowest = sample;
            if (sample < fastest) fastest = sample;
        }
        Arrays.sort(sorted);
        average = (int) Math.round(1000.0 / (total / count));
        minimum = Math.round(1000.0f / slowest);
        maximum = Math.round(1000.0f / fastest);
        p95Millis = sorted[Math.min(count - 1, (int) Math.ceil(count * 0.95) - 1)];
        worstMillis = slowest;
        // Aproximación de 1% low usando el percentil 99 de frametime.
        int p99Index = Math.min(count - 1, Math.max(0, (int) Math.ceil(count * 0.99) - 1));
        lowOnePercent = Math.round(1000.0f / sorted[p99Index]);
    }

    public static int count() { return count; }
    public static float back(int offset) { return SAMPLES[Math.floorMod(index - 1 - offset, SAMPLES.length)]; }
    public static int avg() { return average; }
    public static int min() { return minimum; }
    public static int max() { return maximum; }
    public static int lowOnePercent() { return lowOnePercent; }
    public static float p95Millis() { return p95Millis; }
    public static float worstMillis() { return worstMillis; }
}
