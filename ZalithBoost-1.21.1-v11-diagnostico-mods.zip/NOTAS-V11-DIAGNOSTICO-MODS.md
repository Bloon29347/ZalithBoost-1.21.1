# ZalithBoost 1.21.1 — v11 diagnóstico de mods

## Cambios
- El panel de compatibilidad ahora muestra la versión real de Fabric Loader.
- Muestra las versiones que Fabric cargó de Fabric API, Sodium, Sodium Extra, Lithium, FerriteCore, ModernFix, ImmediatelyFast, C2ME, Noisium, EntityCulling, MoreCulling, Enhanced Block Entities, LambDynamicLights, ScalableLux, Continuity, EMF, ETF, Indium y Mod Menu.
- Esto permite identificar versiones activas sin tener que adivinar el Fabric Loader desde el nombre de los archivos.
- Se conserva el caché de lectura de RAM física, el diagnóstico de memoria y las recomendaciones JVM de v10.
- Se conserva el HUD, editor, perfiles, auto-ajuste y modo anti-calor.

## Límites y validación
- El panel muestra los mods que Fabric cargó; no puede enumerar con fiabilidad todos los JAR duplicados que haya físicamente en la carpeta.
- No modifica internamente Sodium ni los motores de animación, iluminación o texturas.
- No se ha podido compilar en este entorno porque no hay Gradle instalado. Ejecuta el workflow de GitHub Actions antes de instalar el JAR y comparte el resultado si falla.
- No se garantizan aumentos de FPS ni reducciones de RAM sin medirlos en el dispositivo.
