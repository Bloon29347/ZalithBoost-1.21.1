# ZalithBoost 1.21.1 — v10 optimización móvil

## Cambios de esta versión
- Se almacena en caché la lectura de RAM física de `/proc/meminfo`. El panel de diagnóstico puede solicitar sus datos al dibujarse repetidamente; ahora no provoca una lectura del sistema en cada frame. La RAM se actualiza junto al monitor del sistema (aprox. cada 5 segundos).
- La lectura de RAM usa un lector secuencial y se detiene al encontrar `MemTotal`, sin cargar todo el archivo.
- Se retiró el control de “limpieza de memoria” que no realizaba ninguna acción real. No se fuerza `System.gc()`, porque puede introducir pausas.
- Se amplió el panel de diagnóstico para detectar más mods habituales de la instalación mostrada, incluidos Sodium Extra, FerriteCore, ModernFix, ImmediatelyFast, C2ME, Noisium, EMF/ETF, LambDynamicLights, ScalableLux, Continuity e Indium. La detección no implica compatibilidad garantizada.
- La sugerencia JVM mantiene un `Xms` moderado (máximo 1 GB) y recomienda hasta 4 GB de `Xmx` para dispositivos con suficiente RAM física. No asigna toda la RAM del teléfono a Minecraft.
- Se corrigió el README para que indique Minecraft 1.21.1.

## Se conserva
- HUD, mira, tarjeta de entidad, editor táctil, perfiles, auto-ajuste, modo anti-calor y diagnóstico.
- Compatibilidad indirecta: no se inyecta en el renderizador interno de Sodium ni en mods de texturas/animaciones.

## Límites y validación pendiente
- Esta revisión estática no sustituye una compilación. El ZIP debe compilarse con GitHub Actions y probarse en Zalith Launcher.
- No se promete una cifra de FPS ni una reducción de RAM sin medirla en el dispositivo.
- C2ME figura como versión Alpha en la lista del usuario; si hay cierres o errores de chunks, debe probarse temporalmente sin él para aislar la causa.
