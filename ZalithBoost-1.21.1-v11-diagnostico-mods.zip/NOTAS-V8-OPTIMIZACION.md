# ZalithBoost 1.4.0 — base de optimización para 1.21.1

Cambios de código:
- FrameStats guarda 120 muestras de frametime y recalcula sus agregados cada 10 frames, reduciendo trabajo repetido.
- Targeting ejecuta el raycast de selección cada 4 ticks (5 Hz), suficiente para la tarjeta informativa del HUD; mantiene distancia/vida suavizadas entre escaneos.
- HudManager evita iterar y dibujar elementos cuando no hay ningún elemento habilitado.
- Los overlays propios se omiten cuando hay una pantalla abierta. El inventario y la hotbar vanilla siguen siendo responsabilidad de Minecraft/Sodium.
- Se elimina la llamada periódica a System.gc(): una recolección forzada puede producir pausas y no es una optimización general de RAM.
- Gradle 8.12, Java 21 y dependencias objetivo de Minecraft 1.21.1.

Compatibilidad y límites:
- No se inyecta código en el pipeline interno de Sodium, en los atlas de texturas ni en la carga de mods. Esas rutas dependen de versiones concretas y pueden romperse con Sodium, Iris, mods de animación o el renderer Android.
- No se cambia el tamaño de RAM asignado a Java. Más RAM asignada no siempre mejora FPS; el comportamiento depende del dispositivo y del recolector de Java.
- No se puede optimizar el lado servidor desde un mod exclusivamente cliente.
- Las mejoras reducen trabajo propio de ZalithBoost; no garantizan un porcentaje de FPS.
- Pendiente: compilar en GitHub Actions y probar en Zalith Launcher con el conjunto real de mods.

Sugerencia de diagnóstico: probar el juego primero con Sodium solo y luego añadir resource packs y mods de animación por grupos, para identificar cuál introduce tirones.
