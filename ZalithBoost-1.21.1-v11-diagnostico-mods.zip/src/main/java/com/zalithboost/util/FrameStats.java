package com.zalithboost.util;

/** Muestreo pequeño y agregado diferido para evitar recorrer la ventana en cada frame. */
public final class FrameStats {
    private static final float[] SAMPLES = new float[120];
    private static int index, count, frames;
    private static long lastNanos;
    private static int average, minimum, maximum;

    private FrameStats() {}

    public static void frame() {
        long now = System.nanoTime();
        if (lastNanos != 0L) {
            float ms = (now - lastNanos) / 1_000_000.0f;
            if (ms >= 0.1f && ms <= 1000.0f) {
                SAMPLES[index] = ms;
                index = (index + 1) % SAMPLES.length;
                if (count < SAMPLES.length) count++;
            }
        }
        lastNanos = now;
        if (++frames >= 10) {
            frames = 0;
            calculate();
        }
    }

    private static void calculate() {
        if (count == 0) { average = minimum = maximum = 0; return; }
        double total = 0;
        float slowest = 0, fastest = Float.MAX_VALUE;
        for (int i = 0; i < count; i++) {
            float sample = SAMPLES[Math.floorMod(index - 1 - i, SAMPLES.length)];
            total += sample;
            if (sample > slowest) slowest = sample;
            if (sample < fastest) fastest = sample;
        }
        average = (int)Math.round(1000.0 / (total / count));
        minimum = Math.round(1000.0f / slowest);
        maximum = Math.round(1000.0f / fastest);
    }

    public static int count() { return count; }
    public static float back(int offset) { return SAMPLES[Math.floorMod(index - 1 - offset, SAMPLES.length)]; }
    public static int avg() { return average; }
    public static int min() { return minimum; }
    public static int max() { return maximum; }
}
