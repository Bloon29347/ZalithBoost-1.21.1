package com.zalithboost.util;

import java.io.BufferedReader;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Lee batería/temperatura desde /sys (si Android lo permite a la app) y la RAM del dispositivo.
 * Si el sistema bloquea la lectura, los valores quedan como "no disponible".
 */
public final class SystemMonitor {
    public static int battery = -1;                 // % o -1
    public static float tempC = Float.NaN;          // °C o NaN
    private static int t;
    private static long cachedDeviceRamMb = -1;
    private static boolean ramRead;

    private SystemMonitor() {}

    public static void tick() {
        if (t++ % 100 != 0) return; // cada ~5 s
        battery = readInt("/sys/class/power_supply/battery/capacity", -1);
        int raw = readInt("/sys/class/power_supply/battery/temp", Integer.MIN_VALUE);
        tempC = raw == Integer.MIN_VALUE ? Float.NaN : raw / 10f;
        cachedDeviceRamMb = readDeviceRamMb();
        ramRead = true;
    }

    private static int readInt(String p, int def) {
        try { return Integer.parseInt(Files.readString(Path.of(p)).trim()); }
        catch (Exception e) { return def; }
    }

    /**
     * RAM física total en MB. El valor se almacena en caché: Diagnostics puede
     * consultar este dato durante cada frame al dibujar su panel informativo.
     * Leer /proc/meminfo repetidamente desde el renderizado causaría I/O innecesaria.
     */
    public static long deviceRamMb() {
        if (!ramRead) {
            cachedDeviceRamMb = readDeviceRamMb();
            ramRead = true;
        }
        return cachedDeviceRamMb;
    }

    private static long readDeviceRamMb() {
        try (BufferedReader reader = Files.newBufferedReader(Path.of("/proc/meminfo"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("MemTotal:")) {
                    String n = line.replaceAll("[^0-9]", "");
                    return Long.parseLong(n) / 1024;
                }
            }
        } catch (Exception ignored) {}
        return -1;
    }
}
