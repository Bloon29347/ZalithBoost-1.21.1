# ZalithBoost 1.21.1 — correcciones v9

## Correcciones aplicadas tras revisar v8
- Corregida una línea mal formada en `Targeting.java` que impedía compilar el archivo.
- Eliminada una llamada residual a `gc(mc)` en `Perf.java`; el método ya no existía y provocaba error de compilación.
- Se mantiene la decisión de no forzar `System.gc()`, porque puede introducir pausas.

## Objetivo y límites
- Minecraft 1.21.1, Java 21, Fabric.
- Se mantienen los archivos y funciones del proyecto v8.
- No se modifica el código interno de Sodium ni de los mods de animaciones/texturas.
- No se promete un aumento concreto de FPS/RAM: debe medirse en el dispositivo.
- La compilación aún debe verificarse en GitHub Actions; este entorno no tiene Gradle ni las dependencias de Minecraft/Fabric para ejecutar el build.

## Cómo verificar
1. Sube el contenido del ZIP a la raíz del repositorio GitHub (no subas el ZIP como un único archivo).
2. Abre la pestaña **Actions**.
3. Ejecuta o espera el flujo **Build ZalithBoost 1.21.1**.
4. Si falla, comparte el registro completo del primer error rojo. No instales un JAR que no haya terminado correctamente.
