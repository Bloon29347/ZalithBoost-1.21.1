package com.zalithboost.perf;

import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;
import java.util.ArrayDeque;
import java.util.Deque;

/** Lightweight client-side CPS counter. Samples mouse state once per client tick. */
public final class CpsTracker {
    private static final Deque<Long> CLICKS = new ArrayDeque<>();
    private static boolean wasDown;
    private static int cps;
    private CpsTracker() {}

    public static void tick(MinecraftClient client) {
        if (client.getWindow() == null) return;
        boolean down = GLFW.glfwGetMouseButton(client.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_LEFT)
            == GLFW.GLFW_PRESS;
        long now = System.currentTimeMillis();
        if (down && !wasDown) CLICKS.addLast(now);
        wasDown = down;
        while (!CLICKS.isEmpty() && now - CLICKS.peekFirst() > 1000) CLICKS.removeFirst();
        cps = CLICKS.size();
    }
    public static int getCps() { return cps; }
}
