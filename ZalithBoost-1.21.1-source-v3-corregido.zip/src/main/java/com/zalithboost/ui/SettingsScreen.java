package com.zalithboost.ui;

import com.zalithboost.config.ZbConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public final class SettingsScreen extends Screen {
    public SettingsScreen() { super(Text.literal("ZalithBoost")); }
    @Override protected void init() {
        int x = width / 2 - 105, y = Math.max(28, height / 5);
        addToggle(x,y,"HUD",() -> ZbConfig.data.hudEnabled,v -> ZbConfig.data.hudEnabled=v); y+=23;
        addToggle(x,y,"FPS",() -> ZbConfig.data.showFps,v -> ZbConfig.data.showFps=v); y+=23;
        addToggle(x,y,"Coordenadas",() -> ZbConfig.data.showCoords,v -> ZbConfig.data.showCoords=v); y+=23;
        addToggle(x,y,"CPS",() -> ZbConfig.data.showCps,v -> ZbConfig.data.showCps=v); y+=23;
        addToggle(x,y,"Objetivo/enemigo",() -> ZbConfig.data.showTarget,v -> ZbConfig.data.showTarget=v); y+=23;
        addToggle(x,y,"Alertas",() -> ZbConfig.data.showAlerts,v -> ZbConfig.data.showAlerts=v); y+=23;
        addToggle(x,y,"Mira personalizada",() -> ZbConfig.data.customCrosshair,v -> ZbConfig.data.customCrosshair=v); y+=26;
        addDrawableChild(ButtonWidget.builder(Text.literal("Editar posición del HUD"),
            b -> { if (client != null) client.setScreen(new HudEditorScreen()); })
            .dimensions(x,y,210,20).build()); y+=24;
        addDrawableChild(ButtonWidget.builder(Text.literal("Guardar y volver"), b -> close())
            .dimensions(x,y,210,20).build());
    }
    private void addToggle(int x,int y,String name,java.util.function.Supplier<Boolean> get,
                           java.util.function.Consumer<Boolean> set) {
        addDrawableChild(ButtonWidget.builder(Text.literal(name + ": " + (get.get()?"ON":"OFF")), b -> {
            set.accept(!get.get()); ZbConfig.save();
            if (client != null) client.setScreen(new SettingsScreen());
        }).dimensions(x,y,210,20).build());
    }
    @Override public void render(DrawContext ctx,int mouseX,int mouseY,float delta) {
        renderBackground(ctx,mouseX,mouseY,delta);
        ctx.drawCenteredTextWithShadow(textRenderer,title,width/2,Math.max(8,height/5-18),0xFFFFFF);
        super.render(ctx,mouseX,mouseY,delta);
    }
    @Override public void close() { ZbConfig.save(); if (client != null) client.setScreen(null); }
}
