package com.zalithboost.hud;

import com.zalithboost.config.ZbConfig;
import com.zalithboost.perf.PerformanceMonitor;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.MathHelper;

/** HUD compacto con lecturas cacheadas por tick; evita cálculos costosos por frame. */
public final class ZbHud {
    private static int cacheTick, cachedFps, cachedChunks;
    private static String cachedCoords = "";
    private ZbHud() {}
    public static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!ZbConfig.data.hudEnabled || mc.player == null || mc.options.hudHidden) return;
        if (mc.player.age != cacheTick) {
            cacheTick = mc.player.age;
            cachedFps = PerformanceMonitor.fps();
            cachedChunks = PerformanceMonitor.chunks();
            cachedCoords = String.format("XYZ: %d %d %d",
                MathHelper.floor(mc.player.getX()), MathHelper.floor(mc.player.getY()),
                MathHelper.floor(mc.player.getZ()));
        }
        int y = Math.max(2, (int)(mc.getWindow().getScaledHeight() * ZbConfig.data.hudY));
        int x = Math.max(2, (int)(mc.getWindow().getScaledWidth() * ZbConfig.data.hudX));
        int color = (ZbConfig.data.hudOpacity << 24) | (ZbConfig.data.hudColor & 0xFFFFFF);
        if (ZbConfig.data.showFps) { ctx.drawText(mc.textRenderer, "FPS: " + cachedFps, x, y, color, true); y += 11; }
        if (ZbConfig.data.showCoords) { ctx.drawText(mc.textRenderer, cachedCoords, x, y, color, true); y += 11; }
        if (ZbConfig.data.showSystem) ctx.drawText(mc.textRenderer, "Chunks: " + cachedChunks, x, y, color, true);
        CombatHud.render(ctx, mc);
        AlertsHud.render(ctx, mc);
        CustomCrosshair.render(ctx, mc);
    }
}
