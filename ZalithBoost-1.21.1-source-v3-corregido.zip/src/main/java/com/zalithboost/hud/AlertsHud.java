package com.zalithboost.hud;

import com.zalithboost.config.ZbConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemStack;

public final class AlertsHud {
    private static int lowHealthTicks, durabilityTicks;
    private AlertsHud() {}
    public static void render(DrawContext ctx, MinecraftClient mc) {
        if (mc.player == null || !ZbConfig.data.showAlerts) return;
        int y = 8;
        if (ZbConfig.data.lowHealthAlert && mc.player.getHealth() <= ZbConfig.data.lowHealthHearts * 2.0f) {
            lowHealthTicks = 40;
        }
        ItemStack held = mc.player.getMainHandStack();
        if (ZbConfig.data.durabilityAlert && held.isDamageable()
                && held.getMaxDamage() - held.getDamage() <= ZbConfig.data.durabilityThreshold) {
            durabilityTicks = 40;
        }
        if (lowHealthTicks > 0) {
            ctx.drawCenteredTextWithShadow(mc.textRenderer, "¡SALUD BAJA!", mc.getWindow().getScaledWidth()/2, y, 0xFFFF4444);
            lowHealthTicks--;
        }
        if (durabilityTicks > 0) {
            ctx.drawCenteredTextWithShadow(mc.textRenderer, "¡Durabilidad baja!", mc.getWindow().getScaledWidth()/2, y + 12, 0xFFFFAA33);
            durabilityTicks--;
        }
    }
}
