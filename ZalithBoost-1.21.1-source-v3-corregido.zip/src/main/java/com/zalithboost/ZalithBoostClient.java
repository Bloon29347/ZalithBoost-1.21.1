package com.zalithboost;

import com.zalithboost.config.ZbConfig;
import com.zalithboost.perf.PerformanceMonitor;
import com.zalithboost.hud.ZbHud;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public final class ZalithBoostClient implements ClientModInitializer {
    public static KeyBinding openKey;

    @Override public void onInitializeClient() {
        ZbConfig.load();
        PerformanceMonitor.init();
        openKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.zalithboost.open", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_Z,
            "category.zalithboost"));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openKey.wasPressed()) {
                if (client.player != null) client.setScreen(new com.zalithboost.ui.SettingsScreen());
            }
            PerformanceMonitor.tick(client);
        });
        HudRenderCallback.EVENT.register((drawContext, tickCounter) ->
            ZbHud.render(drawContext));
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> ZbConfig.save());
    }
}
